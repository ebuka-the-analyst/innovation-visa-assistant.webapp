<?php
/**
 * Plugin Name: EBL Pro Shipment Tracking (Free)
 * Description: Carrier + tracking for WooCommerce orders. Shows tracking in customer emails, My Account, and a guest tracking shortcode. HPOS-compatible. No paid service required.
 * Version: 1.1.0
 * Author: EBL Universal
 * License: GPL-2.0+
 * Text Domain: ebl-pro-st
 */

if ( ! defined('ABSPATH') ) exit;

if ( ! class_exists('EBL_Pro_ST') ) :

final class EBL_Pro_ST {

    const META_NUM     = '_ebl_st_number';
    const META_CARRIER = '_ebl_st_carrier';
    const META_DATE    = '_ebl_st_date';
    const NONCE_FIELD  = 'ebl_st_nonce';
    const NONCE_ACTION = 'ebl_st_save_meta';
    const OPTS_KEY     = 'ebl_st_settings';

    /** Singleton */
    private static $instance = null;
    public static function instance() {
        return self::$instance ?: ( self::$instance = new self() );
    }

    /** Bootstrap */
    private function __construct() {
        // Load textdomain
        add_action('init', [$this,'load_textdomain']);

        // Woo HPOS compatibility
        add_action('before_woocommerce_init', [$this,'declare_hpos_compat']);

        // Admin UI for order edit (works for POSTS + HPOS)
        add_action('woocommerce_admin_order_data_after_order_details', [$this,'admin_fields']);
        add_action('woocommerce_process_shop_order_meta', [$this,'save_order_fields'], 10, 2);

        // Settings page (simple toggles)
        add_action('admin_menu', [$this,'settings_menu']);
        add_action('admin_init', [$this,'register_settings']);

        // Customer-facing display
        add_action('woocommerce_order_details_after_order_table', [$this,'render_block_front']);
        add_action('woocommerce_email_after_order_table', [$this,'render_block_email'], 10, 4);

        // Shortcode for guest lookup
        add_shortcode('ebl_order_tracking', [$this,'shortcode_lookup']);
    }

    /** ======================== i18n & HPOS ======================== */
    public function load_textdomain() {
        load_plugin_textdomain('ebl-pro-st', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function declare_hpos_compat() {
        if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
        }
    }

    /** ======================== Carriers ======================== */
    public static function carriers() {
        $defaults = [
            'royal_mail' => [
                'label' => __('Royal Mail','ebl-pro-st'),
                'url'   => 'https://www.royalmail.com/track-your-item#/tracking-results/{num}',
            ],
            'dpd_uk' => [
                'label' => __('DPD UK','ebl-pro-st'),
                'url'   => 'https://www.dpd.co.uk/apps/tracking/?reference={num}',
            ],
            'dhl' => [
                'label' => __('DHL Express','ebl-pro-st'),
                'url'   => 'https://www.dhl.com/global-en/home/tracking/tracking-express.html?tracking-id={num}',
            ],
            'parcelforce' => [
                'label' => __('Parcelforce','ebl-pro-st'),
                'url'   => 'https://www.parcelforce.com/track-trace?trackNumber={num}',
            ],
            'ups' => [
                'label' => __('UPS','ebl-pro-st'),
                'url'   => 'https://www.ups.com/track?loc=en_GB&tracknum={num}',
            ],
            'evri' => [
                'label' => __('Evri','ebl-pro-st'),
                'url'   => 'https://www.evri.com/track/parcel/{num}',
            ],
        ];
        /** Allow theme or custom code to extend carriers */
        return apply_filters('ebl_st_carriers', $defaults);
    }

    private static function carrier_link( $key, $number ) {
        $carriers = self::carriers();
        if ( empty($key) || empty($number) || empty($carriers[$key]['url']) ) return '';
        return esc_url( str_replace('{num}', rawurlencode($number), $carriers[$key]['url']) );
    }

    /** ======================== Admin Order UI ======================== */
    public function admin_fields( $order ) {
        if ( ! current_user_can( 'edit_shop_orders' ) ) return;

        $order_id = $order->get_id();
        $num      = $order->get_meta(self::META_NUM);
        $carrier  = $order->get_meta(self::META_CARRIER);
        $date     = $order->get_meta(self::META_DATE);
        $carriers = self::carriers();

        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);

        echo '<div class="order_data_column">';
        echo '<h3>'.esc_html__('Shipment Tracking','ebl-pro-st').'</h3>';

        // Number
        woocommerce_wp_text_input([
            'id'          => 'ebl_st_number',
            'label'       => __('Tracking number','ebl-pro-st'),
            'value'       => $num,
            'wrapper_class' => 'form-field-wide',
        ]);

        // Carrier
        echo '<p class="form-field form-field-wide"><label for="ebl_st_carrier">'.esc_html__('Carrier','ebl-pro-st').'</label>';
        echo '<select id="ebl_st_carrier" name="ebl_st_carrier" class="widefat">';
        echo '<option value="">'.esc_html__('Select a carrier','ebl-pro-st').'</option>';
        foreach ( $carriers as $key => $c ) {
            printf(
                '<option value="%1$s" %2$s>%3$s</option>',
                esc_attr($key),
                selected($carrier, $key, false),
                esc_html($c['label'])
            );
        }
        echo '</select></p>';

        // Date
        woocommerce_wp_text_input([
            'id'          => 'ebl_st_date',
            'label'       => __('Shipped date','ebl-pro-st'),
            'value'       => $date,
            'placeholder' => 'YYYY-MM-DD',
            'description' => __('Use ISO format (YYYY-MM-DD).','ebl-pro-st'),
            'data_type'   => 'text',
            'wrapper_class' => 'form-field-wide',
        ]);

        echo '<p><small>'.esc_html__('Save the order to update emails/My Account output.','ebl-pro-st').'</small></p>';
        echo '</div>';
    }

    public function save_order_fields( $post_id, $post ) {
        if ( ! isset($_POST[self::NONCE_FIELD]) || ! wp_verify_nonce($_POST[self::NONCE_FIELD], self::NONCE_ACTION) ) return;
        if ( ! current_user_can( 'edit_shop_orders' ) ) return;

        $order = wc_get_order( $post_id );
        if ( ! $order ) return;

        $num     = isset($_POST['ebl_st_number'])  ? sanitize_text_field( wp_unslash($_POST['ebl_st_number']) ) : '';
        $carrier = isset($_POST['ebl_st_carrier']) ? sanitize_key( wp_unslash($_POST['ebl_st_carrier']) ) : '';
        $date    = isset($_POST['ebl_st_date'])    ? sanitize_text_field( wp_unslash($_POST['ebl_st_date']) ) : '';

        // Basic ISO date check: YYYY-MM-DD
        if ( $date && ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ) {
            $date = '';
        }

        $order->update_meta_data(self::META_NUM,     $num);
        $order->update_meta_data(self::META_CARRIER, $carrier);
        $order->update_meta_data(self::META_DATE,    $date);
        $order->save();
    }

    /** ======================== Settings ======================== */
    public function settings_menu() {
        add_options_page(
            __('EBL Shipment Tracking','ebl-pro-st'),
            __('EBL Shipment Tracking','ebl-pro-st'),
            'manage_woocommerce',
            'ebl-st-settings',
            [$this,'settings_page']
        );
    }

    public function register_settings() {
        register_setting( self::OPTS_KEY, self::OPTS_KEY, [
            'type'              => 'array',
            'sanitize_callback' => [$this,'sanitize_settings'],
            'default'           => [
                'show_in_emails' => 1,
                'show_on_account'=> 1,
            ],
        ]);

        add_settings_section( 'ebl_st_main', __('Display Options','ebl-pro-st'), '__return_false', 'ebl-st-settings' );

        add_settings_field(
            'show_in_emails',
            __('Show in customer emails','ebl-pro-st'),
            [$this,'field_checkbox'],
            'ebl-st-settings',
            'ebl_st_main',
            ['key'=>'show_in_emails']
        );

        add_settings_field(
            'show_on_account',
            __('Show on My Account → Orders','ebl-pro-st'),
            [$this,'field_checkbox'],
            'ebl-st-settings',
            'ebl_st_main',
            ['key'=>'show_on_account']
        );
    }

    public function sanitize_settings( $input ) {
        $out = [
            'show_in_emails' => empty($input['show_in_emails']) ? 0 : 1,
            'show_on_account'=> empty($input['show_on_account']) ? 0 : 1,
        ];
        return $out;
    }

    public function field_checkbox( $args ) {
        $opts = get_option(self::OPTS_KEY);
        $key  = $args['key'];
        printf(
            '<label><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s> %4$s</label>',
            esc_attr(self::OPTS_KEY),
            esc_attr($key),
            checked( ! empty($opts[$key]), 1, false ),
            esc_html__('Enable','ebl-pro-st')
        );
    }

    public function settings_page() {
        echo '<div class="wrap">';
        echo '<h1>'.esc_html__('EBL Shipment Tracking','ebl-pro-st').'</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields( self::OPTS_KEY );
        do_settings_sections( 'ebl-st-settings' );
        submit_button();
        echo '</form>';
        echo '</div>';
    }

    /** ======================== Output Helpers ======================== */
    private static function tracking_block_html( $order ) {
        $num     = $order->get_meta(self::META_NUM);
        $carrier = $order->get_meta(self::META_CARRIER);
        $date    = $order->get_meta(self::META_DATE);

        if ( empty($num) || empty($carrier) ) return '';

        $carriers = self::carriers();
        $label    = isset($carriers[$carrier]['label']) ? $carriers[$carrier]['label'] : ucfirst(str_replace('_',' ',$carrier));
        $link     = self::carrier_link($carrier, $num);

        ob_start(); ?>
        <section class="ebl-st-block" style="margin:1em 0;padding:12px;border:1px solid #e5e5e5;border-radius:6px;">
            <h3 style="margin:0 0 8px;"><?php echo esc_html__('Shipment Tracking','ebl-pro-st'); ?></h3>
            <p style="margin:0;">
                <strong><?php echo esc_html($label); ?>:</strong>
                <?php if ( $link ) : ?>
                    <a href="<?php echo $link; ?>" target="_blank" rel="noopener">
                        <?php echo esc_html($num); ?>
                    </a>
                <?php else : ?>
                    <?php echo esc_html($num); ?>
                <?php endif; ?>
                <?php if ( $date ) : ?>
                    <br><small><?php printf( esc_html__('Shipped on %s','ebl-pro-st'), esc_html($date) ); ?></small>
                <?php endif; ?>
            </p>
        </section>
        <?php
        return ob_get_clean();
    }

    /** My Account */
    public function render_block_front( $order ) {
        $opts = get_option(self::OPTS_KEY);
        if ( empty($opts['show_on_account']) ) return;
        if ( ! $order instanceof WC_Order ) return;
        echo self::tracking_block_html($order);
    }

    /** Emails */
    public function render_block_email( $order, $sent_to_admin, $plain_text, $email ) {
        $opts = get_option(self::OPTS_KEY);
        if ( empty($opts['show_in_emails']) ) return;
        if ( $sent_to_admin || ! $order instanceof WC_Order ) return;

        $html = self::tracking_block_html($order);
        if ( ! $html ) return;

        if ( $plain_text ) {
            $num     = $order->get_meta(self::META_NUM);
            $carrier = $order->get_meta(self::META_CARRIER);
            $date    = $order->get_meta(self::META_DATE);
            $carriers = self::carriers();
            $label    = isset($carriers[$carrier]['label']) ? $carriers[$carrier]['label'] : $carrier;
            $link     = self::carrier_link($carrier, $num);

            echo "\n=== ".esc_html__('Shipment Tracking','ebl-pro-st')." ===\n";
            echo esc_html__('Carrier','ebl-pro-st').": $label\n";
            echo esc_html__('Number','ebl-pro-st').": $num\n";
            if ( $link ) echo esc_html__('Track','ebl-pro-st').": $link\n";
            if ( $date ) echo esc_html__('Shipped','ebl-pro-st').": $date\n";
        } else {
            echo $html;
        }
    }

    /** ======================== Shortcode ======================== */
    public function shortcode_lookup( $atts ) {
        $atts = shortcode_atts( [], $atts, 'ebl_order_tracking' );
        $msg  = '';
        $out  = '';

        if ( isset($_POST['ebl_st_lookup_nonce']) && wp_verify_nonce( sanitize_text_field(wp_unslash($_POST['ebl_st_lookup_nonce'])), 'ebl_st_lookup' ) ) {
            $order_id = isset($_POST['ebl_st_order_id']) ? absint($_POST['ebl_st_order_id']) : 0;
            $email    = isset($_POST['ebl_st_email'])    ? sanitize_email( wp_unslash($_POST['ebl_st_email']) ) : '';

            if ( $order_id && $email ) {
                $order = wc_get_order($order_id);
                if ( $order && strtolower($order->get_billing_email()) === strtolower($email) ) {
                    $status_name = wc_get_order_status_name( $order->get_status() );
                    $out .= '<div class="ebl-st-lookup" style="margin-top:1em;padding:12px;border:1px solid #e5e5e5;border-radius:6px;">';
                    $out .= '<p><strong>'.esc_html__('Order Status','ebl-pro-st').':</strong> '.esc_html($status_name).'</p>';
                    $out .= self::tracking_block_html($order);
                    $out .= '</div>';
                } else {
                    $msg = '<p style="color:#b00;">'.esc_html__('Order not found or email does not match.','ebl-pro-st').'</p>';
                }
            } else {
                $msg = '<p style="color:#b00;">'.esc_html__('Enter a valid Order ID and Billing Email.','ebl-pro-st').'</p>';
            }
        }

        ob_start(); ?>
        <form method="post" class="ebl-st-form" style="max-width:520px;">
            <p>
                <label><?php echo esc_html__('Order ID','ebl-pro-st'); ?></label><br>
                <input type="number" name="ebl_st_order_id" required style="width:100%;max-width:520px;">
            </p>
            <p>
                <label><?php echo esc_html__('Billing Email','ebl-pro-st'); ?></label><br>
                <input type="email" name="ebl_st_email" required style="width:100%;max-width:520px;">
            </p>
            <?php wp_nonce_field('ebl_st_lookup','ebl_st_lookup_nonce'); ?>
            <p><button type="submit" class="button"><?php echo esc_html__('Track Order','ebl-pro-st'); ?></button></p>
            <?php if ( $msg ) echo $msg; ?>
        </form>
        <?php
        return ob_get_clean() . $out;
    }
}

/** Initialize */
add_action('plugins_loaded', function() {
    if ( class_exists('WooCommerce') ) {
        EBL_Pro_ST::instance();
    }
});

endif; // class exists
